/* eslint-disable react-refresh/only-export-components */

import CollageEditor from "../collage/collageEditor"


export default () =>{


  return(<>
  
<CollageEditor/>

  </>)
}