/* eslint-disable react-refresh/only-export-components */


export default () => {


    return(
        <>
        <h2>More</h2>
        </>
    );
}